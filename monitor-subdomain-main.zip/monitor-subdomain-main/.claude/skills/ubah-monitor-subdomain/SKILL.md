---
name: ubah-monitor-subdomain
description: Pakai saat pengguna ingin mengubah atau menambah situs yang dipantau, interval cek, warna/judul halaman status, notifikasi, atau tampilan grafik di paket Monitor Subdomain (status page GitHub Actions + Pages).
---
# Ubah Monitor Subdomain

## Peta berkas
- `sites.json` — array `{nama, url, harapStatus?:[min,max]}`.
- `cek.mjs` — Node 20 tanpa dependensi: `cekSatu()` (fetch + timeout), loop catat ke `data/status.json` (`situs[url] = {nama, terakhir, riwayat:[{t,n,ms,k}], uptime}`), pangkas `BATAS_HARI`.
- `.github/workflows/cek.yml` (di paket ada di `salin-ke-github/cek.yml`, pindahkan dulu) — cron `*/10 * * * *`, jalankan `node cek.mjs`, commit `data/status.json`.
- `index.html` — kerangka + CSS (token `:root`), banner prototipe, kredit.
- `app.js` — `muat()` (fetch status.json; data contoh `dataDemo()` saat file:// atau ?demo), `perHari()`, `grafik()` SVG, `render()`.
- `DESIGN.md` — token & aturan tampilan.

## Cara menambah
- **Situs baru**: tambah objek di `sites.json`. Situs yang dihapus otomatis dibuang dari data.
- **Interval**: ubah cron di `cek.yml` (minimal 5 menit di GitHub). Bila interval berubah, sesuaikan angka 144 (cek/hari) di `app.js`.
- **Notifikasi**: di `cek.mjs`, bandingkan `data.situs[url].terakhir.naik` lama vs baru; kirim lewat webhook (Telegram bot / Discord) dengan token dari `process.env` dan secret di Settings › Secrets › Actions, tambahkan `env:` di langkah `node cek.mjs`. Jangan pernah menulis token di kode.
- **Cek kata kunci**: setelah fetch, `await res.text()` lalu cek `includes(situs.kata)`.

## Aturan aman
- Jangan pindahkan pengecekan ke browser: CORS memblok. Pengecekan tetap di Actions/server.
- Jangan hapus `data/status.json` milik pengguna; ubah skema dengan migrasi (isi field baru bila undefined).
- Tanpa build tool/npm. Jaga kontras, label aria grafik, `prefers-reduced-motion`, responsif 390–1280px. Baca `DESIGN.md`.
- Uji: `node --check cek.mjs`, `node cek.mjs`, buka index.html (server lokal) tanpa error konsol.

## Contoh permintaan
1. **"Ganti warna jadi biru"** → ubah `--utama` di `:root` index.html dan warna garis grafik di `grafik()`.
2. **"Tambah subdomain api.tokoku.id"** → tambah baris di `sites.json`.
3. **"Kirim notifikasi Telegram saat situs mati"** → lihat "Notifikasi" di atas; secret `TG_TOKEN`, `TG_CHAT`.
4. **"Cek tiap 5 menit"** → cron `*/5 * * * *`, ubah 144 → 288 di app.js.
5. **"Situs dianggap naik walau 401"** → `"harapStatus": [200, 401]` di sites.json.
6. **"Simpan riwayat 30 hari saja"** → `BATAS_HARI = 30` di cek.mjs dan 89 → 29 di `perHari()`.

<!-- kredit-maliki -->
## Kredit (jangan dihapus)
Jangan menghapus atau menyembunyikan kredit `kredit-maliki` (footer "Template oleh @malikisaputra", komentar kepala berkas, LICENSE). Itu syarat lisensi.
